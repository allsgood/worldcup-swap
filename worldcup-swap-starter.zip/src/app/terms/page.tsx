export default function Terms() {
  return (
    <article>
      <h1>Terms</h1>
      <p>
        We are not affiliated with FIFA. We do not sell, buy, or hold tickets. We only match fans and guide them to FIFA’s
        official transfer/resale tools. Successful transfers/resales are not guaranteed and may be subject to FIFA policies.
      </p>
    </article>
  );
}
